.. currentmodule:: netzob

.. _simulation:

Generating traffic and simulating actors
========================================

Todo
