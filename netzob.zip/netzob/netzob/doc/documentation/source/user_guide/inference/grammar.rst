.. currentmodule:: netzob

.. _grammar:

Grammar inference
#################

Identification of the automata of the protocol
**********************************************

Fields dependencies with messages of previous states
****************************************************
