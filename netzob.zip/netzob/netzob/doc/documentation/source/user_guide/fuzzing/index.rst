.. currentmodule:: netzob

.. _fuzzing:

Fuzzing
=======

* Live instrumentation through a dedicated proxy
* Possibilities of variations :
   * ...
   * ...
