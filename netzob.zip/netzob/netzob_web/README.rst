====================
Netzob Web Interface
====================

An *experimental* Web interface for the Netzob application.


Quickstart
----------

Before running shell commands, set the ``FLASK_DEBUG`` environment variable ::

    export FLASK_DEBUG=1

Then run the following commands to bootstrap your environment and start the web interface::

    pip3 install -r requirements/dev.txt
    bower install
    python3 autoapp.py

    
